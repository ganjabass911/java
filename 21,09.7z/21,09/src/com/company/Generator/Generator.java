package com.company.Generator;

public abstract class Generator
{
    int x;
    public abstract int next();
}


