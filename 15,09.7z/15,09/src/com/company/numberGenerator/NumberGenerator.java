package com.company.numberGenerator;

public abstract class NumberGenerator {
    public abstract int next();
}
